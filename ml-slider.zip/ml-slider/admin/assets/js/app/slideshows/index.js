import Slideshow from './Slideshow.vue'
import Toolbar from './Toolbar.vue'

export { Slideshow, Toolbar }
