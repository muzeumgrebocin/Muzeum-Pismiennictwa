<script>
// import { Caption } from '.'
import { EventManager } from '../utils'
export default {
	// Using inline-template for now
	// components: {
	// 	'metaslider-caption': Caption
	// },
	props: {
		id: {
			type: [Number, String],
			default: null
		}
	},
	data() {
		return {}
	},
	mounted() {
	
	}
}
</script>
