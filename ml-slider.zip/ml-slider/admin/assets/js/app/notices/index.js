import CSSManagerNotice from './CSSManagerNotice.vue'
import AnalyticsNotice from './AnalyticsNotice.vue'

export { CSSManagerNotice, AnalyticsNotice }
