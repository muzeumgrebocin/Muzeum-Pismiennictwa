# Easy FancyBox

WordPress plugin to easily enable the FancyBox jQuery extension on just about all media links. Multi-Site compatible. Also supports Youtube, Vimeo, Dailymotion, PDF, iFrame and Flash movies.

[https://wordpress.org/plugins/easy-fancybox/](https://wordpress.org/plugins/easy-fancybox/)
